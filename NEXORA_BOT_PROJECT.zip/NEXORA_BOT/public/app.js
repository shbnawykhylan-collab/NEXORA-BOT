const $ = s => document.querySelector(s);
let currentGuild = null;
async function api(url, options={}) {
  const r = await fetch(url, { credentials:"same-origin", headers:{"Content-Type":"application/json"}, ...options });
  if (!r.ok) throw new Error((await r.json().catch(()=>({}))).error || "request_failed");
  return r.json();
}
async function init(){
  try {
    const user = await api("/api/me");
    if (!user) return;
    $("#userArea").innerHTML = `<span class="hint">مرحبًا، ${escapeHtml(user.username)}</span>`;
    $("#app").classList.remove("hidden");
    const guilds = await api("/api/guilds");
    $("#guildSelect").innerHTML = guilds.map(g=>`<option value="${g.id}">${escapeHtml(g.name)}${g.botPresent?"":" — البوت غير موجود"}</option>`).join("");
    $("#guildSelect").addEventListener("change", loadSettings);
    if(guilds.length) { $("#guildSelect").value=guilds[0].id; await loadSettings(); }
    else $("#guildStatus").textContent="لم نجد سيرفرًا تملك فيه صلاحية الإدارة.";
  } catch(e){ $("#guildStatus").textContent="تعذر تحميل البيانات. تأكد من إعداد OAuth وإضافة البوت للسيرفر."; }
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
async function loadSettings(){
  currentGuild=$("#guildSelect").value;
  if(!currentGuild)return;
  try{
    const s=await api(`/api/settings/${currentGuild}`);
    document.querySelectorAll("[data-key]").forEach(el=>el.checked=!!s[el.dataset.key]);
    $("#welcome_channel").value=s.welcome_channel||"";
    $("#logs_channel").value=s.logs_channel||"";
    $("#language").value=s.language||"ar";
    $("#guildStatus").textContent="تم تحميل إعدادات السيرفر.";
  }catch(e){$("#guildStatus").textContent="البوت غير موجود في السيرفر أو لا تملك صلاحية الإدارة.";}
}
$("#save").addEventListener("click",async()=>{
  const data={};
  document.querySelectorAll("[data-key]").forEach(el=>data[el.dataset.key]=el.checked);
  data.welcome_channel=$("#welcome_channel").value.trim();
  data.logs_channel=$("#logs_channel").value.trim();
  data.language=$("#language").value;
  try{await api(`/api/settings/${currentGuild}`,{method:"PUT",body:JSON.stringify(data)});$("#feedback").textContent="تم حفظ الإعدادات ✓";}
  catch(e){$("#feedback").textContent="تعذر الحفظ: "+e.message;}
});
$("#logout").addEventListener("click",async()=>{await api("/auth/logout",{method:"POST"});location.href="/";});
init();
