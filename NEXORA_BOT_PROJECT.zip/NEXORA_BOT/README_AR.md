# NEXORA BOT — مشروع البداية

بوت ديسكورد مع لوحة ويب عربية/إنجليزية. هذه نسخة أولية قابلة للتشغيل وليست منتجًا مستضافًا أو منشورًا تلقائيًا.

## الأنظمة الموجودة
- لوحة ويب عبر تسجيل دخول Discord OAuth2.
- لوحة أوامر داخل Discord: `/panel` و`/help`.
- تذاكر منفصلة: تصميم شعار، برمجة بوت، تصميم موقع، تنسيق سيرفر، دعم.
- أوامر إدارة: `/warn` و`/warnings` و`/purge` و`/kick` و`/ban` و`/timeout`.
- ترحيب قابل للتفعيل من لوحة الويب.
- حماية أساسية من روابط الدعوات والرسائل المزعجة (Automod).
- سجل حذف الرسائل إلى قناة محددة.
- حفظ الإعدادات والتحذيرات في SQLite.

## المتطلبات
- Node.js 20 أو أحدث.
- تطبيق وبوت من Discord Developer Portal.
- استضافة تدعم Node.js وملفات دائمة/قاعدة SQLite.
- HTTPS عام للوحة الويب عند النشر.

## الإعداد
1. فك ضغط المشروع.
2. نفّذ `npm install`.
3. انسخ `.env.example` إلى `.env`.
4. املأ `DISCORD_BOT_TOKEN`, `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`.
5. اختر `SESSION_SECRET` طويلًا وعشوائيًا.
6. اضبط `BASE_URL` و`CALLBACK_URL` على عنوان موقعك. أضف رابط callback نفسه في OAuth2 Redirects في Discord Developer Portal.
7. فعّل Server Members Intent وMessage Content Intent من صفحة Bot في Developer Portal.
8. أضف البوت إلى سيرفرك بصلاحيات مناسبة، تشمل Manage Channels وView Channels وSend Messages وRead Message History وModerate Members وKick Members وBan Members وManage Messages.
9. نفّذ `npm run register` مرة واحدة لتسجيل أوامر Slash.
10. نفّذ `npm start`.

## ملاحظات مهمة
- لا ترسل التوكن أو Client Secret لأي شخص ولا تضعهما في ملفات عامة.
- لا ترفع ملف `.env` إلى GitHub.
- لوحة الويب تحتاج OAuth2 مضبوطًا مع HTTPS في الإنتاج.
- رابط `/panel` يعرض عنوان لوحة الويب، ويجب أن يكون BASE_URL صحيحًا.
- أوامر التذاكر تحتاج صلاحية Manage Channels للبوت.
- خيار التذاكر في لوحة الويب حاليًا إعداد محفوظ؛ نشر لوحة التذاكر يتم عبر `/setup-tickets`.
- SQLite تحتاج مساحة تخزين دائمة؛ بعض الاستضافات المجانية تمسح الملفات أو توقف الخدمة.
- لا يوجد ضمان لاستضافة مجانية 24/7 بلا حدود. راجع حدود مزود الاستضافة قبل الاعتماد عليه.
- اختبر البوت في سيرفر تجريبي قبل استخدامه في سيرفر العملاء.
