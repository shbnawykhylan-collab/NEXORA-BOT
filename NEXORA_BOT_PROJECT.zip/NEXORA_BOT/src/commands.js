const {
  SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder,
  ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle
} = require("discord.js");
const { ensureGuild, db } = require("./db");

const commands = [
  new SlashCommandBuilder().setName("ping").setDescription("Check bot response / فحص استجابة البوت"),
  new SlashCommandBuilder().setName("help").setDescription("Show commands / عرض الأوامر"),
  new SlashCommandBuilder().setName("panel").setDescription("Open NEXORA control panel / لوحة تحكم نكسورا"),
  new SlashCommandBuilder().setName("setup-tickets").setDescription("Create the ticket panel / إنشاء لوحة التذاكر")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder().setName("close").setDescription("Close this ticket / إغلاق التذكرة"),
  new SlashCommandBuilder().setName("warn").setDescription("Warn a member / تحذير عضو")
    .addUserOption(o => o.setName("member").setDescription("Member / العضو").setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Reason / السبب").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  new SlashCommandBuilder().setName("warnings").setDescription("View member warnings / عرض تحذيرات عضو")
    .addUserOption(o => o.setName("member").setDescription("Member / العضو").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  new SlashCommandBuilder().setName("purge").setDescription("Delete messages / حذف رسائل")
    .addIntegerOption(o => o.setName("amount").setDescription("1 to 100 / من 1 إلى 100").setRequired(true).setMinValue(1).setMaxValue(100))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  new SlashCommandBuilder().setName("kick").setDescription("Kick a member / طرد عضو")
    .addUserOption(o => o.setName("member").setDescription("Member / العضو").setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Reason / السبب").setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  new SlashCommandBuilder().setName("ban").setDescription("Ban a member / حظر عضو")
    .addUserOption(o => o.setName("member").setDescription("Member / العضو").setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Reason / السبب").setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  new SlashCommandBuilder().setName("timeout").setDescription("Timeout a member / إسكات عضو")
    .addUserOption(o => o.setName("member").setDescription("Member / العضو").setRequired(true))
    .addIntegerOption(o => o.setName("minutes").setDescription("Duration in minutes / المدة بالدقائق").setRequired(true).setMinValue(1).setMaxValue(40320))
    .addStringOption(o => o.setName("reason").setDescription("Reason / السبب").setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
].map(c => c.toJSON());

async function makeTicketPanel(channel) {
  const embed = new EmbedBuilder()
    .setColor(0x8B5CF6)
    .setTitle("NEXORA DIGITAL | الدعم والطلبات")
    .setDescription("اختر نوع التذكرة من القائمة أدناه.\nChoose a ticket type from the menu below.")
    .setFooter({ text: "NEXORA BOT • Support Center" });
  const menu = new StringSelectMenuBuilder()
    .setCustomId("nexora_ticket_type")
    .setPlaceholder("اختر نوع طلبك | Select a request")
    .addOptions(
      { label: "تصميم شعار | Logo Design", value: "logo", emoji: "🎨", description: "طلب تصميم شعار أو هوية" },
      { label: "برمجة بوت | Bot Development", value: "bot", emoji: "🤖", description: "طلب برمجة بوت ديسكورد" },
      { label: "تصميم موقع | Website Design", value: "website", emoji: "🌐", description: "طلب تصميم موقع إلكتروني" },
      { label: "تنسيق سيرفر | Server Setup", value: "server", emoji: "🛠️", description: "تنسيق وإعداد سيرفر ديسكورد" },
      { label: "استفسار ودعم | Support", value: "support", emoji: "💬", description: "استفسار أو مساعدة" }
    );
  await channel.send({ embeds: [embed], components: [new ActionRowBuilder().addComponents(menu)] });
}

async function handleCommand(interaction, client) {
  const { commandName, guild, member } = interaction;
  if (!guild) return interaction.reply({ content: "هذا الأمر يعمل داخل السيرفر فقط. | Use this command in a server.", ephemeral: true });
  ensureGuild(guild.id);

  if (commandName === "ping") return interaction.reply({ content: `🏓 Pong! ${client.ws.ping}ms`, ephemeral: true });
  if (commandName === "help") {
    return interaction.reply({ content: [
      "**NEXORA BOT — الأوامر**",
      "`/ping` فحص البوت", "`/panel` لوحة التحكم", "`/setup-tickets` إنشاء لوحة التذاكر",
      "`/warn` تحذير", "`/warnings` سجل التحذيرات", "`/purge` حذف رسائل",
      "`/kick` طرد", "`/ban` حظر", "`/timeout` إسكات", "`/close` إغلاق تذكرة"
    ].join("\n"), ephemeral: true });
  }
  if (commandName === "panel") {
    const url = `${process.env.BASE_URL || "http://localhost:3000"}`;
    const embed = new EmbedBuilder().setColor(0x8B5CF6).setTitle("NEXORA CONTROL")
      .setDescription("إدارة البوت من لوحة الويب أو باستخدام أوامر ديسكورد.\nManage the bot from the web dashboard or Discord commands.")
      .addFields(
        { name: "🎫 التذاكر", value: "إعداد لوحة الطلبات عبر `/setup-tickets`", inline: true },
        { name: "🛡️ الإدارة", value: "استخدم أوامر الإدارة المتاحة", inline: true },
        { name: "🌐 لوحة الويب", value: url, inline: false }
      );
    return interaction.reply({ embeds: [embed], ephemeral: true });
  }
  if (commandName === "setup-tickets") {
    await makeTicketPanel(interaction.channel);
    return interaction.reply({ content: "تم إنشاء لوحة التذاكر. | Ticket panel created.", ephemeral: true });
  }
  if (commandName === "close") {
    if (!interaction.channel.name.startsWith("ticket-")) return interaction.reply({ content: "هذا ليس روم تذكرة. | This is not a ticket channel.", ephemeral: true });
    await interaction.reply("سيتم إغلاق التذكرة خلال ثوانٍ. | Ticket will close shortly.");
    setTimeout(() => interaction.channel.delete().catch(() => {}), 4000);
    return;
  }
  if (commandName === "warn") {
    const user = interaction.options.getUser("member");
    const reason = interaction.options.getString("reason");
    db.prepare("INSERT INTO warnings (guild_id,user_id,moderator_id,reason) VALUES (?,?,?,?)")
      .run(guild.id, user.id, interaction.user.id, reason);
    return interaction.reply({ content: `⚠️ تم تحذير ${user.tag}\nالسبب: ${reason}`, ephemeral: true });
  }
  if (commandName === "warnings") {
    const user = interaction.options.getUser("member");
    const rows = db.prepare("SELECT reason, created_at FROM warnings WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT 10").all(guild.id, user.id);
    return interaction.reply({ content: rows.length ? rows.map((r,i) => `${i+1}. ${r.reason} — ${r.created_at}`).join("\n") : "لا توجد تحذيرات مسجلة.", ephemeral: true });
  }
  if (commandName === "purge") {
    const amount = interaction.options.getInteger("amount");
    const deleted = await interaction.channel.bulkDelete(amount, true);
    return interaction.reply({ content: `تم حذف ${deleted.size} رسالة.`, ephemeral: true });
  }
  if (["kick","ban","timeout"].includes(commandName)) {
    const user = interaction.options.getUser("member");
    const reason = interaction.options.getString("reason") || "No reason provided";
    const target = await guild.members.fetch(user.id).catch(() => null);
    if (!target) return interaction.reply({ content: "لم أجد العضو في السيرفر.", ephemeral: true });
    if (target.id === interaction.user.id) return interaction.reply({ content: "لا يمكنك تطبيق هذا الإجراء على نفسك.", ephemeral: true });
    if (!target.manageable) return interaction.reply({ content: "رتبة البوت لا تسمح بتنفيذ هذا الإجراء.", ephemeral: true });
    if (commandName === "kick") await target.kick(reason);
    if (commandName === "ban") await target.ban({ reason });
    if (commandName === "timeout") await target.timeout(interaction.options.getInteger("minutes") * 60000, reason);
    return interaction.reply({ content: `تم تنفيذ ${commandName} على ${user.tag}.`, ephemeral: true });
  }
}

async function handleSelect(interaction) {
  const type = interaction.values[0];
  const names = { logo: "logo-design", bot: "bot-development", website: "website-design", server: "server-setup", support: "support" };
  const existing = interaction.guild.channels.cache.find(c => c.name === `${names[type]}-${interaction.user.id}`);
  if (existing) return interaction.reply({ content: `لديك تذكرة مفتوحة بالفعل: ${existing}`, ephemeral: true });

  const channel = await interaction.guild.channels.create({
    name: `${names[type]}-${interaction.user.id}`,
    type: ChannelType.GuildText,
    permissionOverwrites: [
      { id: interaction.guild.roles.everyone.id, deny: ["ViewChannel"] },
      { id: interaction.user.id, allow: ["ViewChannel","SendMessages","ReadMessageHistory","AttachFiles"] },
      { id: interaction.client.user.id, allow: ["ViewChannel","SendMessages","ReadMessageHistory","ManageChannels"] }
    ]
  });
  const close = new ButtonBuilder().setCustomId("nexora_close_ticket").setLabel("إغلاق التذكرة | Close").setEmoji("🔒").setStyle(ButtonStyle.Danger);
  const embed = new EmbedBuilder().setColor(0x8B5CF6).setTitle("تم فتح تذكرتك | Ticket opened")
    .setDescription(`مرحبًا ${interaction.user}، اكتب تفاصيل طلبك هنا.\nHello ${interaction.user}, please describe your request here.`)
    .addFields({ name: "نوع الطلب | Request type", value: type });
  await channel.send({ content: `${interaction.user}`, embeds: [embed], components: [new ActionRowBuilder().addComponents(close)] });
  return interaction.reply({ content: `تم فتح تذكرتك: ${channel}`, ephemeral: true });
}
module.exports = { commands, handleCommand, handleSelect };
