require("dotenv").config();
const { REST, Routes } = require("discord.js");
const { commands } = require("./commands");

if (!process.env.DISCORD_BOT_TOKEN || !process.env.DISCORD_CLIENT_ID) {
  console.error("Set DISCORD_BOT_TOKEN and DISCORD_CLIENT_ID in .env first.");
  process.exit(1);
}
const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_BOT_TOKEN);
(async () => {
  const route = process.env.DEV_GUILD_ID
    ? Routes.applicationGuildCommands(process.env.DISCORD_CLIENT_ID, process.env.DEV_GUILD_ID)
    : Routes.applicationCommands(process.env.DISCORD_CLIENT_ID);
  await rest.put(route, { body: commands });
  console.log("NEXORA slash commands registered.");
})().catch(err => { console.error(err); process.exit(1); });
