const Database = require("better-sqlite3");
const fs = require("fs");
const path = require("path");

const dataDir = path.join(__dirname, "..", "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(path.join(dataDir, "nexora.sqlite"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS guild_settings (
  guild_id TEXT PRIMARY KEY,
  language TEXT DEFAULT 'ar',
  tickets_enabled INTEGER DEFAULT 1,
  welcome_enabled INTEGER DEFAULT 0,
  automod_enabled INTEGER DEFAULT 0,
  logs_enabled INTEGER DEFAULT 0,
  welcome_channel TEXT DEFAULT '',
  logs_channel TEXT DEFAULT '',
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS warnings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  moderator_id TEXT NOT NULL,
  reason TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

function ensureGuild(guildId) {
  db.prepare("INSERT OR IGNORE INTO guild_settings (guild_id) VALUES (?)").run(guildId);
  return getSettings(guildId);
}
function getSettings(guildId) {
  ensureRow(guildId);
  return db.prepare("SELECT * FROM guild_settings WHERE guild_id = ?").get(guildId);
}
function ensureRow(guildId) {
  db.prepare("INSERT OR IGNORE INTO guild_settings (guild_id) VALUES (?)").run(guildId);
}
function updateSettings(guildId, data) {
  ensureRow(guildId);
  const allowed = ["language","tickets_enabled","welcome_enabled","automod_enabled","logs_enabled","welcome_channel","logs_channel"];
  const keys = Object.keys(data).filter(k => allowed.includes(k));
  if (!keys.length) return getSettings(guildId);
  const sql = keys.map(k => `${k} = @${k}`).join(", ");
  db.prepare(`UPDATE guild_settings SET ${sql}, updated_at = CURRENT_TIMESTAMP WHERE guild_id = @guild_id`)
    .run({ guild_id: guildId, ...data });
  return getSettings(guildId);
}
module.exports = { db, ensureGuild, getSettings, updateSettings };
