require("dotenv").config();
const { Client, GatewayIntentBits, Events, EmbedBuilder } = require("discord.js");
const express = require("express");
const session = require("express-session");
const passport = require("passport");
const DiscordStrategy = require("passport-discord").Strategy;
const path = require("path");
const { getSettings, ensureGuild, updateSettings } = require("./db");
const { handleCommand, handleSelect } = require("./commands");

const required = ["DISCORD_BOT_TOKEN","DISCORD_CLIENT_ID","DISCORD_CLIENT_SECRET","SESSION_SECRET"];
const missing = required.filter(k => !process.env[k]);
if (missing.length) {
  console.error("Missing .env values:", missing.join(", "));
  process.exit(1);
}

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent]
});

client.once(Events.ClientReady, c => console.log(`NEXORA BOT online as ${c.user.tag}`));

client.on(Events.InteractionCreate, async interaction => {
  try {
    if (interaction.isChatInputCommand()) await handleCommand(interaction, client);
    if (interaction.isStringSelectMenu() && interaction.customId === "nexora_ticket_type") await handleSelect(interaction);
    if (interaction.isButton() && interaction.customId === "nexora_close_ticket") {
      if (!interaction.channel.name.startsWith("ticket-") &&
          !["logo-design-","bot-development-","website-design-","server-setup-","support-"].some(p => interaction.channel.name.startsWith(p))) {
        return interaction.reply({ content: "هذه ليست تذكرة.", ephemeral: true });
      }
      const allowed = interaction.channel.permissionOverwrites.cache.has(interaction.user.id) ||
        interaction.memberPermissions?.has("ManageChannels");
      if (!allowed) return interaction.reply({ content: "لا تملك صلاحية إغلاق هذه التذكرة.", ephemeral: true });
      await interaction.reply("سيتم إغلاق التذكرة الآن.");
      setTimeout(() => interaction.channel.delete().catch(() => {}), 3500);
    }
  } catch (e) {
    console.error(e);
    const msg = { content: "حدث خطأ. تحقق من صلاحيات البوت وإعداداته.", ephemeral: true };
    if (interaction.isRepliable()) {
      if (interaction.deferred || interaction.replied) await interaction.followUp(msg).catch(() => {});
      else await interaction.reply(msg).catch(() => {});
    }
  }
});

client.on(Events.GuildCreate, guild => ensureGuild(guild.id));

client.on(Events.GuildMemberAdd, async member => {
  const s = getSettings(member.guild.id);
  if (!s.welcome_enabled || !s.welcome_channel) return;
  const ch = member.guild.channels.cache.get(s.welcome_channel);
  if (!ch) return;
  ch.send({ embeds: [new EmbedBuilder().setColor(0x8B5CF6).setTitle("أهلًا بك في السيرفر!")
    .setDescription(`مرحبًا ${member} في **${member.guild.name}**`).setThumbnail(member.user.displayAvatarURL())] }).catch(() => {});
});

client.on(Events.MessageCreate, async message => {
  if (!message.guild || message.author.bot) return;
  const s = getSettings(message.guild.id);
  if (s.automod_enabled) {
    const invite = /(discord\.gg\/|discord\.com\/invite\/)/i.test(message.content);
    const spam = /(.)\1{14,}/.test(message.content);
    if ((invite || spam) && !message.member.permissions.has("ManageMessages")) {
      await message.delete().catch(() => {});
      message.channel.send({ content: `${message.author} تم حذف رسالة مخالفة تلقائيًا.` })
        .then(m => setTimeout(() => m.delete().catch(() => {}), 5000)).catch(() => {});
    }
  }
});

client.on(Events.MessageDelete, async message => {
  if (!message.guild) return;
  const s = getSettings(message.guild.id);
  if (!s.logs_enabled || !s.logs_channel) return;
  const ch = message.guild.channels.cache.get(s.logs_channel);
  if (ch) ch.send({ embeds: [new EmbedBuilder().setColor(0xEF4444).setTitle("تم حذف رسالة")
    .addFields({ name: "القناة", value: `${message.channel}`, inline: true },
      { name: "الكاتب", value: message.author ? `${message.author.tag}` : "غير معروف", inline: true })
    .setDescription((message.content || "لا يوجد نص").slice(0, 1000))] }).catch(() => {});
});

const app = express();
app.use(express.json());
app.use(session({ secret: process.env.SESSION_SECRET, resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 86400000 } }));
app.use(passport.initialize());
app.use(passport.session());

passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((obj, done) => done(null, obj));
passport.use(new DiscordStrategy({
  clientID: process.env.DISCORD_CLIENT_ID,
  clientSecret: process.env.DISCORD_CLIENT_SECRET,
  callbackURL: process.env.CALLBACK_URL,
  scope: ["identify","guilds"]
}, (accessToken, refreshToken, profile, done) => done(null, profile)));

const requireAuth = (req,res,next) => req.isAuthenticated() ? next() : res.status(401).json({ error: "login_required" });
app.get("/auth/discord", passport.authenticate("discord"));
app.get("/auth/discord/callback", passport.authenticate("discord", { failureRedirect: "/" }), (req,res) => res.redirect("/"));
app.post("/auth/logout", (req,res) => req.logout(() => req.session.destroy(() => res.json({ ok: true }))));
app.get("/api/me", (req,res) => res.json(req.user ? { id:req.user.id, username:req.user.username, avatar:req.user.avatar } : null));
app.get("/api/guilds", requireAuth, async (req,res) => {
  const manageable = (req.user.guilds || []).filter(g => (BigInt(g.permissions) & 0x20n) === 0x20n || (BigInt(g.permissions) & 0x8n) === 0x8n);
  const list = manageable.map(g => {
    const botGuild = client.guilds.cache.get(g.id);
    return { id:g.id, name:g.name, icon:g.icon, botPresent:!!botGuild };
  });
  res.json(list);
});
app.get("/api/settings/:guildId", requireAuth, (req,res) => {
  const g = client.guilds.cache.get(req.params.guildId);
  if (!g || !(req.user.guilds || []).some(x => x.id === g.id && ((BigInt(x.permissions)&0x20n)===0x20n || (BigInt(x.permissions)&0x8n)===0x8n)))
    return res.status(403).json({ error:"no_access" });
  res.json(getSettings(g.id));
});
app.put("/api/settings/:guildId", requireAuth, (req,res) => {
  const g = client.guilds.cache.get(req.params.guildId);
  if (!g || !(req.user.guilds || []).some(x => x.id === g.id && ((BigInt(x.permissions)&0x20n)===0x20n || (BigInt(x.permissions)&0x8n)===0x8n)))
    return res.status(403).json({ error:"no_access" });
  const body = req.body || {};
  const clean = {};
  for (const k of ["language","welcome_channel","logs_channel"]) if (typeof body[k] === "string") clean[k] = body[k].slice(0,30);
  for (const k of ["tickets_enabled","welcome_enabled","automod_enabled","logs_enabled"]) if (typeof body[k] === "boolean") clean[k] = body[k] ? 1 : 0;
  res.json(updateSettings(g.id, clean));
});
app.use(express.static(path.join(__dirname, "..", "public")));
app.get("*", (req,res) => res.sendFile(path.join(__dirname, "..", "public", "index.html")));

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`NEXORA dashboard listening on ${port}`));
client.login(process.env.DISCORD_BOT_TOKEN);
